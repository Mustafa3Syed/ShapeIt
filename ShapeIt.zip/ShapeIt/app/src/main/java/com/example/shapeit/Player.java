package com.example.shapeit;

import androidx.appcompat.widget.ThemedSpinnerAdapter;

public class Player {
    private String Name;
    private int level;
    private int lives;
    public Player(String name)
    {
        this.Name=name;
        level=0;
        lives=3;
    }
    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }
}


