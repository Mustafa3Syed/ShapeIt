package com.example.shapeit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ThemedSpinnerAdapter;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

import android.os.Handler;

public class level extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (HelperMethods.currentPlayer.getLevel() > 0) {
            setContentView(R.layout.activity_level);
        } else {
            setContentView(R.layout.activity_loss);
        }
        defineButtons();
        Lives();
    }

    private void defineButtons() {
        findViewById(R.id.PauseLevel).setOnClickListener(buttonClickListener);
        findViewById(R.id.startGameButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape1).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape2).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape3).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape4).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape5).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape6).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape7).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape8).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape9).setOnClickListener(buttonClickListener);
        findViewById(R.id.shape10).setOnClickListener(buttonClickListener);
    }

    private void Lives() {
        ImageView LifeOne = (ImageView) findViewById(R.id.LifeOne);
        ImageView LifeTwo = (ImageView) findViewById(R.id.LifeTwo);
        ImageView LifeThree = (ImageView) findViewById(R.id.LifeThree);

        if (HelperMethods.currentPlayer.getLives() == 3) {
            LifeOne.setVisibility(View.VISIBLE);
            LifeTwo.setVisibility(View.VISIBLE);
            LifeThree.setVisibility(View.VISIBLE);
        } else if (HelperMethods.currentPlayer.getLives() == 2) {
            LifeOne.setVisibility(View.VISIBLE);
            LifeTwo.setVisibility(View.VISIBLE);
            LifeThree.setVisibility(View.INVISIBLE);
        } else if (HelperMethods.currentPlayer.getLives() == 1) {
            LifeOne.setVisibility(View.VISIBLE);
            LifeTwo.setVisibility(View.INVISIBLE);
            LifeThree.setVisibility(View.INVISIBLE);
        } else {
            LifeOne.setVisibility(View.INVISIBLE);
            LifeTwo.setVisibility(View.INVISIBLE);
            LifeThree.setVisibility(View.INVISIBLE);
        }


    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.startGameButton:
                    startGame();
                    break;
                case R.id.PauseLevel:
                    openPauseMenu(view);
                    break;
                case R.id.shape1:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(1);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape2:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(2);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape3:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(3);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape4:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(4);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape5:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(5);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape6:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(6);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape7:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(7);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape8:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(8);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape9:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(9);
                    }
                    WinOrLossVerify();
                    break;
                case R.id.shape10:
                    if (HelperMethods.playerSequence.size() < HelperMethods.computerSequence.size()) {
                        HelperMethods.playerSequence.add(10);
                    }
                    WinOrLossVerify();
                    break;
            }
        }


        private void openPauseMenu(View view) {
            Intent intent = new Intent(view.getContext(), pause.class);
            startActivity(intent);
        }

        private void startGame() {
            int choice;
            ArrayList<Integer> Selectedbuttons = HelperMethods.SelectButtons(HelperMethods.currentPlayer.getLevel());
            Button startGame = (Button) findViewById(R.id.startGameButton);
            buttonsSelection(Selectedbuttons);
            buttonShapeSetter(Selectedbuttons);
            for (int x = 0; x < HelperMethods.currentPlayer.getLevel(); x++) {
                choice = HelperMethods.blinkingButtons(Selectedbuttons);
                buttonBlinker(choice);
                HelperMethods.computerSequence.add(choice);
            }
            startGame.setVisibility(View.INVISIBLE);
        }

        private void WinOrLossVerify() {
            System.out.println(HelperMethods.computerSequence.size());
            Button startGame = (Button) findViewById(R.id.startGameButton);
            if (HelperMethods.computerSequence.size() == HelperMethods.playerSequence.size()) {
                HelperMethods.winOrLoss();
                HelperMethods.computerSequence.clear();
                HelperMethods.computerSequence.trimToSize();
                HelperMethods.playerSequence.clear();
                HelperMethods.playerSequence.trimToSize();
                startGame.setVisibility(View.VISIBLE);
                startGame.setClickable(true);
                setAllVisibilities();
                setShapes();
            }
        }

        private void buttonsSelection(ArrayList<Integer> Selectedbuttons) {
            Button shape1 = (Button) findViewById(R.id.shape1);
            Button shape2 = (Button) findViewById(R.id.shape2);
            Button shape3 = (Button) findViewById(R.id.shape3);
            Button shape4 = (Button) findViewById(R.id.shape4);
            Button shape5 = (Button) findViewById(R.id.shape5);
            Button shape6 = (Button) findViewById(R.id.shape6);
            Button shape7 = (Button) findViewById(R.id.shape7);
            Button shape8 = (Button) findViewById(R.id.shape8);
            Button shape9 = (Button) findViewById(R.id.shape9);
            Button shape10 = (Button) findViewById(R.id.shape10);

            if (!Selectedbuttons.contains(1)) {
                shape1.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(2)) {
                shape2.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(3)) {
                shape3.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(4)) {
                shape4.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(5)) {
                shape5.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(6)) {
                shape6.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(7)) {
                shape7.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(8)) {
                shape8.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(9)) {
                shape9.setVisibility(View.INVISIBLE);
            }
            if (!Selectedbuttons.contains(10)) {
                shape10.setVisibility(View.INVISIBLE);
            }
        }

        private void buttonShapeSetter(ArrayList<Integer> selectedButtons) {
            Button shape1 = (Button) findViewById(R.id.shape1);
            Button shape2 = (Button) findViewById(R.id.shape2);
            Button shape3 = (Button) findViewById(R.id.shape3);
            Button shape4 = (Button) findViewById(R.id.shape4);
            Button shape5 = (Button) findViewById(R.id.shape5);
            Button shape6 = (Button) findViewById(R.id.shape6);
            Button shape7 = (Button) findViewById(R.id.shape7);
            Button shape8 = (Button) findViewById(R.id.shape8);
            Button shape9 = (Button) findViewById(R.id.shape9);
            Button shape10 = (Button) findViewById(R.id.shape10);
            int shapes;
            int specificButton;
            for (int x = 0; x < selectedButtons.size(); x++) {
                shapes = HelperMethods.RandomShapes();
                Drawable background;
                specificButton = selectedButtons.get(x);
                switch (specificButton) {
                    case 1:
                        shapeSetter(shape1, shapes);
                        break;
                    case 2:
                        shapeSetter(shape2, shapes);
                        break;
                    case 3:
                        shapeSetter(shape3, shapes);
                        break;
                    case 4:
                        shapeSetter(shape4, shapes);
                        break;
                    case 5:
                        shapeSetter(shape5, shapes);
                        break;
                    case 6:
                        shapeSetter(shape6, shapes);
                        break;
                    case 7:
                        shapeSetter(shape7, shapes);
                        break;
                    case 8:
                        shapeSetter(shape8, shapes);
                        break;
                    case 9:
                        shapeSetter(shape9, shapes);
                        break;
                    case 10:
                        shapeSetter(shape10, shapes);
                        break;
                }
            }
        }

        private void shapeSetter(Button button, int shapes) {
            if (shapes == 1) {
                button.setBackgroundResource(R.drawable.ic_baseline_emoji_emotions_24);
            } else if (shapes == 2) {
                button.setBackgroundResource(R.drawable.ic_baseline_emoji_emotions_24);
            } else if (shapes == 3) {
                button.setBackgroundResource(R.drawable.ic_baseline_local_fire_department_24);
            } else if (shapes == 4) {
                button.setBackgroundResource(R.drawable.ic_baseline_pan_tool_24);
            } else {
                button.setBackgroundResource(R.drawable.ic_baseline_favorite_24);
            }
        }

        private void buttonBlinker(int choice) {
            Button shape = getButton(choice);
            shape.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.red));
            delayColor(shape);
        }

        private void delayColor(Button button) {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Do something after 3s = 3000ms
                    button.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.purple_500));
                }
            }, 1500);
        }

        private Button getButton(int choice) {
            Button buttonChoice;
            if (choice == 1) {
                buttonChoice = (Button) findViewById(R.id.shape1);
            } else if (choice == 2) {
                buttonChoice = (Button) findViewById(R.id.shape2);
            } else if (choice == 3) {
                buttonChoice = (Button) findViewById(R.id.shape3);
            } else if (choice == 4) {
                buttonChoice = (Button) findViewById(R.id.shape4);
            } else if (choice == 5) {
                buttonChoice = (Button) findViewById(R.id.shape5);
            } else if (choice == 6) {
                buttonChoice = (Button) findViewById(R.id.shape6);
            } else if (choice == 7) {
                buttonChoice = (Button) findViewById(R.id.shape7);
            } else if (choice == 8) {
                buttonChoice = (Button) findViewById(R.id.shape8);
            } else if (choice == 9) {
                buttonChoice = (Button) findViewById(R.id.shape9);
            } else {
                buttonChoice = (Button) findViewById(R.id.shape10);
            }
            return buttonChoice;

        }

        private void setAllVisibilities() {
            findViewById(R.id.shape1).setVisibility(View.VISIBLE);
            findViewById(R.id.shape2).setVisibility(View.VISIBLE);
            findViewById(R.id.shape3).setVisibility(View.VISIBLE);
            findViewById(R.id.shape4).setVisibility(View.VISIBLE);
            findViewById(R.id.shape5).setVisibility(View.VISIBLE);
            findViewById(R.id.shape6).setVisibility(View.VISIBLE);
            findViewById(R.id.shape7).setVisibility(View.VISIBLE);
            findViewById(R.id.shape8).setVisibility(View.VISIBLE);
            findViewById(R.id.shape9).setVisibility(View.VISIBLE);
            findViewById(R.id.shape10).setVisibility(View.VISIBLE);
        }
        private void setShapes() {
            findViewById(R.id.shape1).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape2).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape3).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape4).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape5).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape6).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape7).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape8).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape9).setBackgroundResource(android.R.drawable.btn_default);
            findViewById(R.id.shape10).setBackgroundResource(android.R.drawable.btn_default);

        }
    };
}

