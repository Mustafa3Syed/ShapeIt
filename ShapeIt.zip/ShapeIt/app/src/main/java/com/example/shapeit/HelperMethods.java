package com.example.shapeit;

import android.widget.EditText;

import java.util.*;

    
public class HelperMethods {
    public static Player[] Leaderboard = new Player[10];
    public static Player currentPlayer=new Player("dweqweqw");
    public static Random rand = new Random();
    public static boolean canPlay = false;
    public static ArrayList<Integer> computerSequence = new ArrayList<>();
    public static ArrayList<Integer> playerSequence = new ArrayList<>();
    public static int totalDelay;


    public static boolean verifyName(String name)
    {
        boolean newName=true;
        for(int x=0; x< Leaderboard.length;x++) {
            if (Leaderboard[x] == null) {
                break;
            }
            else if (Leaderboard[x].getName().equals(name)) {
                newName = false;
            }
        }
        return newName;
    }
    public static void manageLeaderBoard(Player currentPlayer) {
        Player temp;
        Player secondTemp;
        temp = currentPlayer;
        for (int x = 0; x <=Leaderboard.length; x++) {
            if (HelperMethods.Leaderboard[x] == null)
            {
                HelperMethods.Leaderboard[x]=temp;
                break;
            }
            else if (Leaderboard[x].getLevel() == currentPlayer.getLevel() && Leaderboard[x].getName() == currentPlayer.getName()) {
                break;
            } else if (Leaderboard[x].getLevel() < currentPlayer.getLevel()) {
                secondTemp = Leaderboard[x];
                Leaderboard[x]=temp;
                temp=secondTemp;
            }
        }
    }

    public static void StartGame(String playerName) {
        currentPlayer = new Player(playerName);
    }

    public static ArrayList<Integer> SelectButtons(int total) {
        ArrayList<Integer> Buttons = new ArrayList<>();
        int random;
        if (total > 0 && total < 10) {
            for (int x = 0; x < total; x++) {
                random = rand.nextInt(10) + 1;
                if (Buttons.contains(random)) {
                    --x;
                    continue;
                }
                Buttons.add(random);
            }
        } else {
            Buttons.add(1);
            Buttons.add(2);
            Buttons.add(3);
            Buttons.add(4);
            Buttons.add(5);
            Buttons.add(6);
            Buttons.add(7);
            Buttons.add(8);
            Buttons.add(9);
            Buttons.add(10);
        }
        return Buttons;
    }

    public static int RandomShapes() {
        Random rand = new Random();
        int randomShape = 0;
        randomShape = rand.nextInt(5) + 1;
        return randomShape;
    }

    public static int blinkingButtons(ArrayList<Integer> selectButtons) {
        int choice;
        choice = selectButtons.get(rand.nextInt(selectButtons.size()));
        return choice;
    }

    public static void winOrLoss() {
        if (verifyWinner() == true) {
            currentPlayer.setLevel(currentPlayer.getLevel() + 1);
        } else {
            currentPlayer.setLives(currentPlayer.getLives() - 1);
        }
    }

    public static boolean verifyWinner() {
        boolean verify = true;
        if (computerSequence.size() == 0) {
            verify = false;
        }
        for (int x = 0; x < computerSequence.size(); x++) {
            if (computerSequence.get(x) != playerSequence.get(x)) {
                verify = false;
            }
        }
        return verify;
    }
}

