package com.example.shapeit;

public class HelperMethods {
        public static Player[] Leaderboard=new Player[10];

}
