package com.example.shapeit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class new_game extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
        findViewById(R.id.submissionNewGame).setOnClickListener(buttonClickListener);
    }
    public static String leaderBoardName;

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {
            openLevel(view);
        }
        private void openLevel(View view) {
            EditText name=(EditText) findViewById(R.id.NameNewGame);
            leaderBoardName=name.getText().toString();
            Intent intent=new Intent(view.getContext(),level.class);
            startActivity(intent);
        }
    };
}