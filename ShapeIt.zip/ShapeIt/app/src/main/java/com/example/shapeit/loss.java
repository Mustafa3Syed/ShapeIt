package com.example.shapeit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class loss extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loss);
        defineButtons();
        TextView Score=(TextView) findViewById(R.id.ScoreLoss);
        HelperMethods.manageLeaderBoard(HelperMethods.currentPlayer);
        Score.setText(String.format("Your Score Was: %d",HelperMethods.currentPlayer.getLevel()));

    }

    private void defineButtons()
    {
        findViewById(R.id.NewGameLoss).setOnClickListener(buttonClickListener);
        findViewById(R.id.LeaderboardLoss).setOnClickListener(buttonClickListener);
        findViewById(R.id.MainMenuLoss).setOnClickListener(buttonClickListener);
    }
    private View.OnClickListener buttonClickListener=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch(view.getId()){
                case R.id.NewGameLoss:
                    openNewGame(view);
                    break;
                case R.id.LeaderboardLoss:
                    openLeaderboard(view);
                    break;
                case R.id.MainMenuLoss:
                    openMainMenu(view);
                    break;
            }
        }
        private void openNewGame(View view)
        {
            Intent intent=new Intent(view.getContext(),new_game.class);
            startActivity(intent);
        }
        private void openLeaderboard(View view)
        {
            Intent intent=new Intent(view.getContext(),leaderboard.class);
            startActivity(intent);
        }
        private void openMainMenu(View view)
        {
            Intent intent=new Intent(view.getContext(),MainActivity.class);
            startActivity(intent);
        }
    };
}